# Amigaplex

**The Amiga version of Supaplex (1991), ported to Windows.**

*Supaplex* is a fast puzzle game with some action. You play **Murphy**, a
small red ball living inside a computer. In each of **111 levels** you must
collect enough **infotrons** and reach the **exit**, while zonks fall around
you, disks explode and snik snaks hunt you through the circuits.

Amigaplex is not a remake. It runs the original Amiga program, translated
instruction by instruction into modern code. The levels, graphics, music and
every rule of the game are exactly those of the 1991 Amiga disk; only the
parts around the game (window, keyboard, sound output) are new. A **level
editor** is included.

## How to play

1. Unpack the archive anywhere and start `amigaplex.exe`.
2. Click to skip the intro, click **new player**, type your name, press
   **Enter**, then **Space** to start level 1.

Nothing is installed. The game keeps everything in its own folder, so you
can copy it to a USB stick and play on any 64-bit Windows 7 or newer.

The archive includes a full illustrated manual, `Amigaplex_Manual.html`: every
object, the menu, the settings and the editor.

## Controls

| Where | Action | Keys and buttons |
|---|---|---|
| Menu | everything | mouse; <kbd>Space</kbd> starts the selected level |
| In a level | move | arrow keys, gamepad D-pad or left stick |
| | fire (snap, plant a red disk) | <kbd>Space</kbd>, gamepad A / B / X / Y |
| | pause | <kbd>P</kbd> or the right mouse button |
| | give up | <kbd>Esc</kbd> |
| Anywhere | full screen | <kbd>F11</kbd> or <kbd>Alt</kbd>+<kbd>Enter</kbd> |
| | quit | <kbd>F12</kbd> |

## What the port adds

The game logic is not changed: every level plays exactly as on an Amiga.
Everything new is about how you control the game and how it looks.

* **No Amiga and no disk image needed.** The data files are in the `data`
  folder.
* **Keyboard and gamepad** instead of the Amiga joystick, with the keys DOS
  players know: <kbd>Space</kbd>, <kbd>Esc</kbd>, <kbd>P</kbd>.
* **Skippable intro.**
* **No accidental clicks.** A click left over from the previous screen does
  not press a button on the next one, and the left mouse button no longer
  blows Murphy up in the middle of a level.
* **Smooth scrolling**, with an optional 50 Hz full-screen mode that shows
  the game at its true speed.
* A resizable window, full screen, pause when minimized.

## Amiga and DOS

Supaplex is best known in its DOS version. The two versions are separate
programs written by different people, and they differ in more than looks:
the Amiga has only two sound effects, stores a start camera in every level,
has an extra "no crush" zonk setting, switches special ports at a different
moment and plants red disks with different timing. The manual has the full
comparison.

Level files made for DOS can be imported into the editor, which adapts them
to the Amiga rules.

## The level editor

`amigaplex_editor.exe` edits the 111 levels with the game's own graphics.

* pencil, line, frame, box, fill and selection tools; copy, paste, mirror
* unlimited undo for each level
* level settings: title, gravity, zonk mode, infotrons needed, start camera
* special ports with their own gravity and freeze settings
* **Check** (<kbd>F7</kbd>) finds problems; **Play** (<kbd>F5</kbd>) starts
  the game on the level you are editing
* import and export of `.SP` levels and whole `LEVELS.DAT` files, including
  DOS ones
* English or Russian, light or dark theme

## Credits

**Supaplex** (1991): written by **Philip Jespersen**, visuals by **Michael
Stopp**, music by **David Whittaker**. Think!ware Development · Dream
Factory · published by Digital Integration Ltd.

**Amigaplex** (Windows port and level editor): **DarkSoL** (aka
**Kufterin**), Discord: `darksol41`.

### Thanks

* To the **Supaplex community**, which has kept this game alive for more
  than thirty years with levels, tools, research and good company.
* To **Gregot** for his help and advice, and for suggesting the name.

Gregot is the author of **Megaplex Online**, an excellent free online
version of Supaplex and the home of its community. If you enjoy Supaplex,
come and join:

* Megaplex Online: <https://www.megaplex.website/>
* Discord server: <https://www.megaplex.website/discord/>

## License and legal

* **The original game.** *Supaplex* (its program, graphics, music and
  levels) was published in 1991 by Digital Integration Ltd, which held the
  copyright. Digital Integration was acquired by Titus Interactive in 1998
  and no longer exists. This project claims **no rights** to the original
  game. The files in the `data` folder come unmodified from the 1991 Amiga
  release and are included only so that the game can be played as it was.
* **An unofficial fan project.** Amigaplex is **non-commercial** and is not
  affiliated with, authorized, sponsored or endorsed by the original
  authors, by Digital Integration or its successors, or by any other holder
  of rights in *Supaplex*.
* **Not connected with inArcade.** This project has no relation to inArcade
  or to the *Supaplex* games they publish for PC, mobile devices and
  consoles. It uses none of their code, graphics, levels or other material.
  "SUPAPLEX" is a registered trademark of its owner in the United States;
  the name appears here only to identify the 1991 game that this is a port
  of.
* **Trademarks.** Amiga, Windows and all other names mentioned are
  trademarks of their respective owners and are used for identification
  only.
* **Amigaplex and its editor** are **free**. You may play and share them
  freely, but please **do not sell** them or include them in paid products.
* **SDL2** is © Sam Lantinga and contributors, used under the zlib license.
* **Rights holders:** if you own rights in anything included here and want
  it changed or removed, contact the author (Discord: `darksol41`).
