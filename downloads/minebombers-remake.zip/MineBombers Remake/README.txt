==============================================================================
          M I N E   B O M B E R S   3 . 1 1   -   T H E   R E M A K E
==============================================================================

  The 1996 DOS classic of digging, gold and dynamite - rebuilt from the
  original program instruction by instruction, then grown much bigger.

  Original game (c) Skitso Productions 1996.
  Remake, level editor and new graphics by DarkSoL   (Discord: darksol41)

  >>> The full illustrated manual is MANUAL.html - open it in any browser.


------------------------------------------------------------------------------
 START
------------------------------------------------------------------------------
  Run MineBombers.exe. Nothing to install - every library is in this folder.
  Keep the folder somewhere writable (not in Program Files).

  New game -> players -> PLAY -> Match setup -> F2 starts.


------------------------------------------------------------------------------
 TWO GAMES IN ONE
------------------------------------------------------------------------------
  Main menu -> Remake -> REMAKE MODE

    OFF  the exact 1996 original: same rules, numbers, sounds - and bugs.
    ON   everything new. Each of the 165 settings can still be turned off.


------------------------------------------------------------------------------
 WHAT IS NEW
------------------------------------------------------------------------------
  * 9 modes      Classic, Battle Royale, Grail, Sandbox, Team Deathmatch,
                 Co-op, Survival, Custom Campaign, Adventure
  * Adventure    a huge random world: biomes, ruins, camps, quests, a grail
  * Content      +29 bombs, +3 items, +17 monsters, +21 tiles
  * Bots         3 skills; they simulate the world ahead, so they understand
                 every bomb
  * Match setup  map vote, draft, chaos mode, blacklist, purchase limit,
                 shop rotation, mirror match, teams, friendly fire
  * Gamepads     up to 4, rumble, hot plugging; mouse in menus
  * Maps         61 original + 300 community maps, 10 generator types,
                 search / sort / favourites, new level editor
  * Stats        round summary with death and map replays, medals,
                 match report, player profiles (F1 on the players screen)
  * Replays      every round recorded, rewind; campaign and Adventure saves
  * Effects      particles, blood, damage numbers, adjustable shake,
                 stereo by position, separate volumes, own music modules
  * Info         encyclopedia pages for everything new, item cards in shop


------------------------------------------------------------------------------
 DEFAULT KEYS (as in the original)
------------------------------------------------------------------------------
             move            stop    bomb/buy    choose/sell   remote
  Player 1   keypad 4 6 8 2  Num5    PgDn        PgUp / Enter  Num1 / End
  Player 2   A D W X         S       Tab         `             Z
  Player 3   K ; O .         L       I           8             ,
  Player 4   arrows          `       RCtrl       RShift        RAlt

  Player 2 is NOT WASD: S is stop, down is X. The ` key stops player 4
  and cycles player 2's weapon - that clash is in the original.
  Change everything in Options -> REDEFINE KEYS.

  On a level:  P pause   F5 music   Esc end level   F10 end match
               hold CHOOSE: item strip      Adventure: M map, Q quests


------------------------------------------------------------------------------
 GAMEPADS
------------------------------------------------------------------------------
  Assign a pad in REDEFINE KEYS like keys. Put STOP and REMOTE on buttons.
  Menus: stick = arrows, BOMB = Enter, STOP = back, CHOOSE = Tab,
         REMOTE = KEYS window with every other key.
  Level and shop: hold STOP for a second - KEYS window (leave, pause...).
  Match setup: START is under the last row. Names need a keyboard.


------------------------------------------------------------------------------
 FILES
------------------------------------------------------------------------------
  MineBombers.exe         the game
  MineBombersEditor.exe   level editor (F1 inside lists every key)
  MANUAL.html             the full manual
  LEVELS\                 maps (*.MNE, *.MNL) - drop new ones in
  assets\mb.pak           graphics, sounds, music
  The game writes its settings, players, saves and replays next to the exe.
  No log files.

  Display: 640x480 drawn, window at double size, resizable, always sharp.
           Force a scale with:  MineBombers.exe --scale 1


------------------------------------------------------------------------------
  Unofficial, free, non-commercial fan project, not affiliated with
  Skitso Productions. Includes the original game data under the authors'
  2001 freeware release. Free to play and share unmodified; not for sale.
  Rights holders: contact darksol41 on Discord. Details in NOTICE.txt.
==============================================================================
