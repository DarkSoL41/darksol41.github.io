# Putup (DOS, 1991) — Reverse-Engineering Report

This document consolidates everything confirmed about the file formats and
game logic of *Putup*, a DOS game built with Turbo Pascal 6/7. It reflects
the final, corrected understanding after a full analysis pass (disassembly
in IDA Pro, static byte analysis, and in-game verification) — earlier,
superseded hypotheses from intermediate work have been removed in favor of
the confirmed facts below.

## 1. Executive summary

**Fully solved:**
- ✅ `PUTUP.EXE` is a plain Turbo Pascal 6/7 executable, not packed.
- ✅ Level format (`PUTUP7.DAT`): 184-byte records, 8-byte header + a
  16×11 tile map, stored **column-major**. ~51 level slots.
- ✅ Level header: exit spawn point, enemy types, enemy positions — all
  16 fields decoded (see §3).
- ✅ Tile ID table (0–13), confirmed by in-game testing.
- ✅ Character/object sprite format (`PUTUP1/2/3/4/5/6.DAT`, the `SPRITES`
  module): row-interleaved EGA planes + mask, palette extracted from the
  EXE. Fully decoded — player, enemies, tiles, HUD, font all render
  correctly (see §4).
- ✅ Hardcoded game mechanics not stored in any file: player start
  position, enemy count, and the number of balls required per level
  (see §3.5).

**Still unsolved:**
- ❌ Pixel encoding of the large 32×32 background-tile graphics in
  `PUTUP10.DAT` / `PUTUP11.DAT`. The container/directory format is fully
  understood, but the pixel payload itself is not a plain bitmap in any
  tested layout — likely compressed or otherwise transformed. Not needed
  for the level editor, since all tiles actually used on maps are drawn
  from the (fully solved) `SPRITES` files instead.
- ❌ A handful of raw tile-map byte values (50, 51, 52, 54, 234) that
  appear rarely in real level data. Verified in-game to render as
  **nothing** (empty) — likely unused/reserved values, not investigated
  further.
- ❌ The in-EXE text-string cipher (`plaintext[i] = ciphertext[i] + i`)
  is known but has not been applied to decode every resource string.

## 2. File roles

| File | Size | Role |
|---|---|---|
| `PUTUP.EXE` | 36,512 B | Main executable (Turbo Pascal 6/7, unpacked) |
| `PUTUP1.DAT` | 3,564 B | SPRITES: tiles, fruit, enemies, HUD icons |
| `PUTUP2.DAT` | 10,752 B | SPRITES: 8×8 font + UI (digits, A-Z, borders, icons) |
| `PUTUP3.DAT` | 3,402 B | SPRITES: player (walk / face-camera), pistol, fire |
| `PUTUP4.DAT` | 1,296 B | SPRITES: EXIT sign + enemies |
| `PUTUP5.DAT` | 2,430 B | SPRITES: tiles + "no monster" sign + "DEAD" + fruit variants |
| `PUTUP6.DAT` | 1,620 B | SPRITES: enemy animation frames |
| `PUTUP7.DAT` | 9,384 B | **Level data** — 184 bytes/level, ~51 levels |
| `PUTUP8.DAT` | 206 B | Encrypted text (same cipher as EXE strings) |
| `PUTUP9.DAT` | 82,740 B | Audio (PCM sample, PC speaker/Sound Blaster) |
| `PUTUP10.DAT` | 66,673 B | 32×32 background tile graphics (container solved, pixels not) |
| `PUTUP11.DAT` | 70,963 B | Same format as PUTUP10.DAT, second tile set |

## 3. Level format (`PUTUP7.DAT`)

### 3.1 Record layout

```
seek = (level_number - 1) * 184
record = header[8 bytes] + map[176 bytes]
```

Confirmed directly from the disassembly (`PUTUP.EXE`, level-load routine):

```
seek_pos = (level_number - 1) * 184
Seek(PUTUP7.DAT, seek_pos)
header[8] = ReadBytes(8)          ; 8 individual 1-byte reads

for col = 0 to 15:                 ; 16 columns (outer loop)
    for row = 0 to 10:              ; 11 rows (inner loop)
        raw_tile = ReadByte()        ; one byte at a time
        map[col][row] = raw_tile     ; buffer index = col*11 + row
```

The map is stored **column-major** (176 bytes = 16 columns × 11 rows), not
row-major. This was the source of a lot of earlier confusion when the map
was read row-major by mistake — no compression is involved; it's a plain
byte array.

File size (9,384 bytes) minus nothing (no leading file header) divided by
184 gives **51 level slots**.

### 3.2 Header byte layout (fully decoded)

```
byte[0]  — exit spawn X (half-tiles; real column = byte / 2)
byte[1]  — exit spawn Y (half-tiles; real row    = byte / 2)
byte[2]  — enemy #1 type   (1-2 = rogach/horizontal, 3-4 = hat/vertical, 5-8 = smiley/flying)
byte[3]  — enemy #1 X (half-tiles)
byte[4]  — enemy #1 Y (half-tiles)
byte[5]  — enemy #2 type
byte[6]  — enemy #2 X (half-tiles)
byte[7]  — enemy #2 Y (half-tiles)
```

All coordinates are stored at half-tile (16px) resolution — i.e. the raw
byte is the pixel position divided by 16, so the real tile-grid coordinate
is `raw / 2`.

The exit-coordinate hypothesis (`header[0..1]` = exit spawn X,Y) was
verified against three real levels exactly:

| Level | header[0], header[1] | → col, row |
|---|---|---|
| 1 | 20, 16 | col 10, row 8 |
| 2 | 28, 16 | col 14, row 8 |
| 3 | 8, 18  | col 4, row 9 |

### 3.3 Tile ID table

Confirmed by direct in-game testing (not just statistical guessing):

| ID | Meaning |
|---|---|
| 0 | empty |
| 1 | brick wall |
| 2 | monster wall (invisible barrier for enemies) |
| 3 | "?" block |
| 4 | secret wall — looks like a brick, but turns into a "?" block (tile 3) when the player stands on it and presses Down |
| 5 | fire |
| 6 | ball — must be carried to a notched wall (tile 7) |
| 7 | notched wall — receiving slot for a ball |
| 8 | exit |
| 9 | cherry |
| 10 | apple |
| 11 | pineapple |
| 12 | grape |
| 13 | heart (extra life) |

A few rare raw values seen in real level data (50, 51, 52, 54, 234) were
checked directly in-game and turned out to render as nothing — most likely
unused/reserved IDs, not a hidden object type.

### 3.4 Enemies are not freely placed — sprite-only slots

The game always has **exactly 2 enemies** per level; the count is not a
field in the file, it's hardcoded. Each enemy's type and position are
stored explicitly in the header (§3.2) — this was confirmed to be
consistent across a wide sample of real levels (10+ levels checked with
zero exceptions for type ranges, 6+ levels checked with zero exceptions for
coordinates).

### 3.5 Mechanics hardcoded in the EXE (not stored in any file)

Three gameplay parameters turned out to be constant/derived rather than
stored as data:

- **Player start position** is always row 1, column 1, on every level.
- **Enemy count** is always exactly 2.
- **Number of balls required to make the exit appear** depends only on the
  level number (not stored anywhere in the header), following this
  hardcoded rule (confirmed by in-game testing):

  | Levels | Balls required |
  |---|---|
  | 1–9   | 1 |
  | 10–19 | 2 |
  | 20–29 | 3 |
  | 30–39 | 4 |
  | 40–49 | 5 |
  | 50+   | 6 |

  Placing more balls than required has no additional effect — the exit
  appears as soon as the required count is reached.

## 4. Sprite graphics format — SPRITES module (fully solved)

The game's error strings reveal an in-house unit literally called
`SPRITES` (`"Module SPRITES: File with sprites not found"`, `"Bad step x
for sprite"`), used for `PUTUP1.DAT` through `PUTUP6.DAT`. This is
completely decoded.

### 4.1 Frame layout

```
byte 0        = W  (row width in BYTES; pixel width = W * 8)
byte 1        = H  (height in rows = pixel height)
frame_size    = 5*W*H + 2
frame N (1-based): seek = (N-1) * frame_size
```

All six SPRITES files use `W=2, H=16` → 16×16-pixel frames.

### 4.2 Pixel plane layout — the key fix

The first (wrong) assumption was that the 4 colour planes are stored
back-to-back per frame (plane 0 in full, then plane 1, etc.), followed by
the mask. That produced only noise for anything except very simple shapes.

The actual layout, confirmed from the real blit routine in the
disassembly (`sub_163B3`, which drives the EGA Sequencer Map Mask port
`0x3C4`): **planes are interleaved per row**. For each row, 4 chunks of `W`
bytes appear back-to-back — one chunk per EGA colour plane — followed
(after all rows) by the `W*H`-byte transparency mask plane. The plane
order is **reversed**: the first chunk in a row maps to bit/plane 3, the
last to plane 0.

```python
# pseudocode
data  = frame[2:]                    # skip the W,H header bytes
color = data[:4*W*H]                 # 4 interleaved colour planes
mask  = data[4*W*H:5*W*H]            # 1 transparency mask plane

for row in range(H):
    row_base = row * 4 * W
    for byte_in_row in range(W):
        for chunk in range(4):
            plane = 3 - chunk        # reversed order
            bits_for_this_byte |= color[row_base + chunk*W + byte_in_row]  # contributes to `plane`
```

### 4.3 Palette

Extracted directly from a DOSBox-X debug overlay screenshot (16 EGA
palette register values). Indices 0 and 6 are both black, indices 4 and 7
are both red — this is a real feature of the palette, not a decoding
artifact:

```
0=(0,0,0)      1=(84,84,252)  2=(0,168,0)    3=(84,84,84)
4=(168,0,0)    5=(168,0,168)  6=(0,0,0)      7=(168,0,0)
8=(0,168,168)  9=(168,168,168) 10=(84,252,84) 11=(84,252,252)
12=(252,84,84) 13=(252,84,252) 14=(252,252,84) 15=(252,252,255)
```

### 4.4 Confirmed content per file

| File | Content |
|---|---|
| `PUTUP1.DAT` | Bricks, "?" block, secret wall, fire, ball, notched wall, exit sign, fruit (cherry/apple/pineapple/grape), heart, enemies, HUD elements |
| `PUTUP2.DAT` | 8×8 font: digits 0-9, A-Z, "HIGHSCORE" text, UI borders/icons (256 frames) |
| `PUTUP3.DAT` | Player: walking pose + face-camera pose (used on death/exit), pistol + muzzle flash, fire/explosion |
| `PUTUP4.DAT` | EXIT sign (both a colourful bordered variant and a plain black/white/red variant), three enemy types |
| `PUTUP5.DAT` | Tiles, "no monster" warning sign, "DEAD" text, fruit/HUD variants |
| `PUTUP6.DAT` | Enemy animation frames |

### 4.5 Enemy sprite categories

| Raw type value | Category | Sprite |
|---|---|---|
| 1–2 | rogach (horizontal) | arch/horn-shaped creature |
| 3–4 | hat (vertical) | rounded blue creature with legs |
| 5–8 | smiley (flying) | yellow round face |

## 5. Background tile graphics — `PUTUP10.DAT` / `PUTUP11.DAT` (unsolved)

The container format is fully understood from the disassembly
(`sub_14854`, the file-loading routine):

```
[0:20]     global header (20 bytes)
[20:35]    signature/version (byte at relative offset 9 must equal 2, or the
           game calls Halt(1) — confirmed against PUTUP10.DAT)
[35:48]    extra parameters (chunk count, scale factor)
[48:1008]  30 tile-directory records, 32 bytes each
[1008:1136] 128-byte shared block (likely a palette)
[1136:...]  N*1024-byte shared chunks
[...]       actual tile pixel blocks, addressed by the directory
```

Each 32-byte directory record includes a file pointer (`offset * 16` =
real byte offset, paragraph-aligned) and a block size (0 = unused slot).
Only 10 of 30 possible slots are used in `PUTUP10.DAT`, and the tiles are
laid out contiguously (verified: tile 0 ends exactly where tile 1 begins,
modulo a few padding bytes).

The problem: real block sizes (585, 563, 407, 592, 125, 213, 400, 256, 619
bytes) are far larger than a raw 32×32 bitmap would need (128 bytes at
1bpp, 512 bytes at 4bpp/16-colour). Multiple decoding hypotheses were
tried (row-major and column-major bitmaps at various widths, RLE, half-tile
grids) and none produced a clean, unambiguous tile image. This format
remains **unsolved**.

This does not block the level editor: every tile ID actually placed on a
level map (§3.3) is drawn from the fully-solved SPRITES files instead, so
`PUTUP10.DAT`/`PUTUP11.DAT` graphics are not required for editing levels.

## 6. Tools produced during this analysis

- `decode_putup_sprites.py` — reference decoder for the SPRITES format
  (§4), reusable for any of the six sprite files.
- `putup_level_editor_v1.0.html` — a self-contained, single-file level
  editor (see `README.md` for usage) with all real sprites embedded.

## 7. Summary

*Putup* is an unpacked Turbo Pascal 6/7 game. Its level format and all
gameplay-relevant sprite graphics are fully decoded and documented above.
The only remaining open question — the pixel encoding of the large
32×32 background-tile files — does not block practical level editing,
since the editor draws every placeable tile from the already-solved
SPRITES sprite set.
