# TETCOLOR — Remake

*[Русская версия](README.ru.md)*

An exact clone of **TETCOLOR** (Sergey Sotnikov, Tula, 1991) for modern
Windows. Not "inspired by" — a reproduction of the original's behaviour: the
same coordinates, fonts, sounds, scoring formulas and animations, all taken
from the original program's machine code.

The game runs as a single file. No DOSBox, no installer, no external
libraries.

---

## About the game

Coloured pieces of three cubes fall into a well seven cells wide. Three or
more cubes of the same colour in a row — horizontally, vertically or along
any diagonal — burn away, everything above collapses down, and what falls may
line up into a new combination. That is how cascades happen.

What sets it apart from Tetris is that the piece is always the same shape:
what you have to think about is colour. A run of 3 to 7 scores, and the
longer it is the steeper the reward — 3 cubes horizontally give 50 points,
7 give 12500. Diagonals are worth the most.

The level rises over time, and each one makes the pieces fall faster.

---

## Running the game

Download `tetcolor.exe` and run it. Alongside the game you will find:

* `TETCOLOR.REZ` — the high score table (the original's format);
* `TETCOLOR.CFG` — settings, plain text;
* `Demos\` — recorded games, if you turn recording on.

---

## Controls

| Key | Action |
|---|---|
| `4` / `6` | left / right |
| `8` / `5` | rotate forward / backward |
| `Space` | drop the piece |
| `S` | sound on / off |
| `Esc` | end the game |
| `Q` | quit |

All of the above are the original's controls. The arrow keys and the numeric
keypad work as well. The remake adds two keys: **`F1`** for settings and
**`F2`** for the list of recorded games; both work at any time.

---

## What the remake adds

The guiding rule: **the defaults reproduce the 1991 original.** Every new
feature stays off until you turn it on, so you can play exactly the game that
was, and everything else is optional.

### Settings (`F1`)

| Setting | Values | Default |
|---|---|---|
| SOUND | on / off | on |
| VOLUME | 0..100 % | 2 % |
| FALL SPEED | ORIGINAL / SLOWER | ORIGINAL |
| BEEP GAP | 0..40 ms | 11 ms |
| WINDOW | 1x..4x | 2x |
| BOT | OFF / HINT / AUTOPLAY | OFF |
| BOT DEPTH | 1 / 2 | 1 |
| BOT SPEED | 0..300 ms | 40 ms |
| ANIMATION | ORIGINAL / FAST | ORIGINAL |
| RECORD DEMOS | on / off | off |
| DEMO ON TITLE | on / off | off |
| RESET TO DEFAULTS | back to the original | — |

Settings are saved to `TETCOLOR.CFG` next to the game. While the menu is
open, the game is paused.

### Volume

In the original, the volume was whatever the physical PC speaker did — that
beep you could hear across the room. Here it is adjustable: the step is one
percent at the quiet end and coarser further up. While the VOLUME item is
selected, every arrow press plays a beep at the new volume, so you can tune
it by ear.

### The bot: hints and autoplay

The bot enumerates every reachable "rotation + column" combination (up to 68
of them), plays each move through to the end — destructions, collapsing,
cascades — and scores the resulting board. In **HINT** mode it shows, with a
white frame, where it suggests placing the piece. In **AUTOPLAY** it plays on
its own.

It gets no privileges: it presses the same keys a human has, and it does not
peek into the future — it only spins the random number generator on copies of
the state.

**A game in which the bot was enabled even once counts neither for the high
score table nor as a recording.** One switch-on is enough, in any mode, hints
included: otherwise someone else's work would sit in the Top 30 next to
honest play. The bottom left corner shows whether the game still counts.

### Recording and replaying games

Turn on `RECORD DEMOS` and every game saves itself into the `Demos` folder.
There is nothing to press — the recording closes together with the game.

What is stored is the generator's seed and the list of keypresses stamped in
timer ticks, so the file is tiny — a 220-piece game takes 7 KB — and the
replay is exact down to the last cell, not "roughly similar".

**`F2`** opens the list of recordings, best on top. During playback `←` and
`→` change the speed from 1x to 8x; any other key stops it. `DEMO ON TITLE`
plays the best recording on the title screen after a while of inactivity.

### Fast mode

`ANIMATION FAST` removes the step-by-step erase animation and the bonus
display: cells vanish instantly and the game moves noticeably faster. The
sound of a piece landing stays — fast mode removes the spectacle, not the
feedback to your actions.

It affects neither the score nor the rules: a move is resolved in full before
anything is drawn, and only the display is skipped.

---

## How accurate is it

The project was built on one rule: **any deviation from the original is a
bug**, and behaviour is never guessed at — it is extracted from the machine
code.

How that was checked:

* an **8086 interpreter** was written that executes the original's real
  machine code. For every key procedure the same situation is run through
  both the original and the remake, and the results are compared byte by
  byte. The last full campaign found **zero discrepancies** across 6825
  collision cases, 390 rotations, 300 generator seeds and 250 board
  positions;
* a **graphics tracer** logs every BGI call with its exact arguments — that
  is how all the on-screen coordinates were obtained, rather than eyeballed;
* the original **runs under DOSBox**, where reference frames at 640×480 are
  captured and the sound is recorded. The bitmap font, the well and the cell
  frames match **pixel for pixel**; the sound frequencies were measured from
  the recording and matched those of the 8253 timer exactly (800.26, 1601.52,
  2400.38 and 2002.99 Hz);
* the falling speed comes from the DOS clock, which does not run continuously
  but in steps of 54.925 ms — which makes the real fall interval noticeably
  longer than the nominal one. Level 1 was measured on the real game: 0.936 s
  and 0.950 s against a modelled 0.934.

What does **not** match, stated plainly: the line rasterisation of the
Triplex stroke font inside the EGAVGA.BGI driver. Letter positions and
dimensions are exact, but 3.9 % of the pixels inside the glyphs on the title
screen still differ — the driver picks points slightly differently from any
of the two dozen variants of Bresenham's algorithm that were tried. Closing
this needs the driver itself taken apart.

And what cannot be closed at all: the timbre. Everything the program
determines — the sequence of sounds, the frequencies, the durations, the
square wave — is reproduced exactly. Beyond that lies the physics of one
particular speaker in one particular case, and that is not in the code.

---

## Credits

**The original game** — Sergey Sotnikov, Tula, 1991. Written in Turbo Pascal
with Borland BGI graphics.

**The remake** — DarkSoL (Discord: `darksol41`).

**Reverse engineering and code** — done together with Claude (Anthropic): the
disassembly, the 8086 emulator for differential testing, the clone's code and
the tests.

---

## Rights

This is an unofficial, free, non-commercial fan remake, made out of respect for the
original. It is not affiliated with or endorsed by the author of the original game.
The rights to TETCOLOR itself belong to its author, Sergey Sotnikov.

**What is in this package.** The original `TETCOLOR.EXE` is **not** included. The
remake is a new program that reproduces the behaviour of the original. To draw the
title text exactly as the original does, the executable contains the data of the
BGI Triplex stroke font, © 1987 Borland International.

No warranty of any kind. If you are a rights holder and want something changed or
removed, contact me on Discord (`darksol41`) and I will do it.
